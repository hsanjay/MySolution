Version: 2.1.0.RELEASE
Build Date: 20101104124840

* Adds an APRLifecycleListener to detect the APR based native library required to use the APR/native connector
* Adds an APR/native (APR) connector for HTTPS
* Adds sample certificate and key files that can be used to test the SSL configuration

NOTE: That the APR/native library must be present in order to use the APR connector
NOTE: The sample certificate and key files are not suitable for production systems