Version: 2.1.0.RELEASE
Build Date: 20101104124840

* Adds a Blocking IO (BIO) connector for HTTP