Version: 2.1.0.RELEASE
Build Date: 20101104124840

* Adds a Blocking IO (BIO) connector for HTTPS
* Adds sample certificate and key files that can be used to test the SSL configuration

NOTE: The sample certificate and key files are not suitable for production systems.