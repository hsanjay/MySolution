Version: 2.1.0.RELEASE
Build Date: 20101104124840

* Sets Xmx to 512M
* Sets Xss to 192K
* Adds a control script to the instance
* Adds the Windows service wrapper libraries
* Adds a default catalina.policy that to be used when starting with the -security option
* Adds a default jmxremote configuration with a read/write user called 'admin' with a password of 'springsource'
* Adds a default JULI logging configuration
* Adds a default server configuration containing
	* A JRE memory leak prevention listener
	* A tc Runtime Deployer listener
	* A JMX socket listener
	* An in-memory user database
	* A threadpool that has up to 300 threads
	* A host that uses 'webapps' as it's app base.
* Adds a default Tomcat user configuration that is empty
* A root web application